#explore_package
This is a simple example of creating and consuming a distributable
Python package.
While I find the Python language to be intuitive and useful
So this is to just be a simple example of how to create and consume a package
 as a reference for myself.

 ##building this package locally
 'python setup.py sdist'
